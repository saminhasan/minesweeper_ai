import customtkinter as ctk


class CustomApp(ctk.CTk):
    def __init__(self, rows=5, cols=5):
        super().__init__()

        # Configure the main window
        self.title("CustomTkinter Rounded Grid")
        self.resizable(False, False)  # Make window non-scalable

        # Top Frame
        self.top_frame = ctk.CTkFrame(self, corner_radius=0)
        self.top_frame.grid(row=0, column=0, sticky="ew", padx=10, pady=5)
        self.grid_rowconfigure(0, weight=1)  # Top frame gets minimal weight
        self.grid_columnconfigure(0, weight=1)  # Ensure the frame stretches horizontally

        # Label in the top frame
        self.label = ctk.CTkLabel(self.top_frame, text="This is the top frame", font=("Arial", 16))
        self.label.grid(row=0, column=0, pady=10, sticky="ew")

        # Bottom Frame
        self.bottom_frame = ctk.CTkFrame(self, corner_radius=0)
        self.bottom_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=5)
        self.grid_rowconfigure(1, weight=10)  # Bottom frame gets more weight for resizing


        self.rows = rows
        self.cols = cols
        self.buttons = []
        self.create_buttons()

        # Adjust the layout to ensure square buttons
        self.update_idletasks()  # Finalize geometry calculations
        self.adjust_button_sizes()

    def create_buttons(self):
        """Create buttons in the grid."""
        for i in range(self.rows):
            for j in range(self.cols):
                button = ctk.CTkButton(
                    self.bottom_frame,
                    # text=f"{i + 1}, {j + 1}",
                    text=f"",
                    corner_radius=10,  # Rounded corners for buttons
                    command=lambda x=i, y=j: self.on_button_click(x, y)
                )
                button.grid(row=i, column=j, padx=5, pady=5, sticky="nsew")
                self.buttons.append(button)

        # Configure grid weights for equal spacing
        for i in range(self.rows):
            self.bottom_frame.grid_rowconfigure(i, weight=1)
        for j in range(self.cols):
            self.bottom_frame.grid_columnconfigure(j, weight=1)

    def adjust_button_sizes(self):
        """Ensure buttons are square by adjusting their width and height."""
        self.update_idletasks()  # Ensure layout dimensions are updated

        # Calculate available cell size
        frame_width = self.bottom_frame.winfo_width()
        frame_height = self.bottom_frame.winfo_height()
        cell_size = min(frame_width // self.cols, frame_height // self.rows)  + 15# Square size

        # Adjust all buttons to be square
        for button in self.buttons:
            button.configure(width=cell_size, height=cell_size)

    def on_button_click(self, row, col):
        """Handle button click event."""
        print(f"Button at ({row + 1}, {col + 1}) clicked!")


if __name__ == "__main__":
    ctk.set_appearance_mode("System")  # Use system appearance (dark/light mode)
    ctk.set_default_color_theme("blue")  # Set default color theme

    app = CustomApp(rows=6, cols=8)
    app.mainloop()
